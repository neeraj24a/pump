define(['jquery', 'backbone',
    // Require Bootstrap JS here so that all
    // pages can assume it is present.
    // Note that this module does not export anything,
    // it just augments jQuery
    'bootstrap', 'collections/common/localeInfo'
], function ($, Backbone, BootStrap, localeInfo) {
    // Variables used in router scope for goals.
    var goalSummaryLandingModel = undefined;
    var goalSummaryArchivedModel = undefined;
	var vent = undefined;
	//Backbone.history.start({ pushState: true });
    var AppRouter = Backbone.Router.extend({
        routes: {
            // URL routes
            'home': 'loadHome',
			'pool': 'loadPool',
			'investment_details':'showInvestmentDetails',
            'overall_portfolio': 'showOverallPortfolio',
            'portfolio_short_term': 'showShortTerm',
			'portfolio_long_term'  : 'showPortfolioLongTerm',
            'liquid_assets': 'showLiquidAssets',
            'goals': 'loadGoal',
            'goal_detail':'goalDetail',
			'goal_detail_new':'goalDetailNew',
            'finance_insurance': 'financeInsurance',
            'archieved_goal': 'ArchievedGoaldRoute',
			//change for CBOL
			'mac_deposits': 'showMACDeposits',
			'mac_loans': 'showMACLoans',
			 'mac_insurance': 'showMACInsurance',
             // Default
             '*actions': 'logoutAndShowError'
        },
        /*logoutAndShowError: function(){
        	if(App.CBOLChannel){
        		$.ajax({
                    url: contextRootFull + '/CBOL/Logout',
                    type: 'GET',
					async: false,
                    success: function (resp) {
                        deleteCookie('cbol_channel');
                        //window.location.href = cbolResp.logoff_URL;
                    },
                    error: function (err) {
                        //vent.render(err, 'promptMessage');
                        deleteCookie('cbol_channel');
                        //window.location.href = cbolResp.logoff_URL;
                    }
                });
				$.ajax({
                    url: cbolResp.rasso_ERROR_URL,
                    type: 'GET',
					async: false,
                    success: function (resp) {
                        deleteCookie('cbol_channel');
                        //window.location.href = cbolResp.logoff_URL;
                    },
                    error: function (err) {
                        //vent.render(err, 'promptMessage');
                        deleteCookie('cbol_channel');
                        //window.location.href = cbolResp.logoff_URL;
                    }
                });
        		window.location.href=contextRootFull + "/ctpra/html/ErrorPage.html";
        		
        	}
        },*/
        initialize: function (options) {
			this.vent = options.vent;
			vent = this;
           // this.listenTo(options.vent, 'deleteTrigger', this.showConfirmDialog);
           // this.commonUtilsView = new CommonUtilsView();
        },
        
		loadHome: function(){
			requirejs([
				'views/home/homeView',
			], function(homeView){
				new homeView();
			});
		},
		
		loadPool: function(){
			requirejs([
				'views/pool/poolView',
			], function(poolView){
				new poolView();
			});
		},
		
		goalDetail: function () {
            var t = this;
            //this.animationHeader();
            requirejs([
               'views/goals/goalDetailView',
               'models/goals/goalDetailModel',
               'models/goals/goalDetailTableModel',
               ], function (goalDetailView,goalDetailModel, goalDetailTableModel) {
            	var a = localeInformation.models[0].get('goalDetails');
            	/*new goalDetailView({
       				goalDetailResponse:localeInformation.models[0].get('goalDetails'),
                       vent: t.vent,
                       goalDetailTableResponse:goalDetailTableResponse                                         
                       
                   });*/
            	if(a.goalDetails.attributes.goalDetail.attributes.displayModifiedFlag=="Y"){
                	new goalDetailView({
           				goalDetailResponse:localeInformation.models[0].get('goalDetails'),
                        vent: t.vent,  
                        goalDetailTableResponse:null
                       });
                }else{
            	var GoalDetailTableModel=new goalDetailTableModel();
       			GoalDetailTableModel.fetch({
               		url: isDemoApp ? 'testdata/goalHolding1.json' : contextRootFull + '/v1/wealth/holdings/goals/holdingsByGoal?goalID=' + localeInformation.models[0].get('goalID'),
       				success:function(goalDetailTableResponse){
               			new goalDetailView({
               				goalDetailResponse:localeInformation.models[0].get('goalDetails'),
                               vent: t.vent,
                               goalDetailTableResponse:goalDetailTableResponse                                         
                               
                           });
               		},
                   	error: function (jqXHR, status, error) {
                    	if (error) 
                    		self.commonUtilsView.render(error, 'promptMessage');
                    }
               	});
              }	
              
			}); 
                
		$('#top-nav').hide();
		$('#top-nav-one').hide();
		$('.hdr-main #LangShow, .hdr-main #currencyShow, .hdr-main #clientProfilePlay').hide();
		$('#top-nav-two, .hdr-main #nameShow, .hdr-main #currencyShowNoSelect').show();
		$('main').css('margin-top', '53px');
		$('.sticker-bottom').hide();
		$('.session-id').hide();
    },
		
		goalDetailNew:function() {        	
            var t = this;
            var screenID = 'RA49,RA64';
            languageBundle.fetch({
            	url: isDemoApp ? 'testdata/getContentAPI.json' : contextRootFull + '/content/applicationID/Citiplanner/viewID/' + screenID + '?contentType=codedValues,languageBundles&indexValue=FOREX_CCY_LIST',
                success: function () {
                	requirejs(['views/goals/detailNewView'], function(detailNewView) {
                    	new detailNewView({
                            vent: t.vent
                    	});                    
                        $('#top-nav').hide();
                        $('main').css('margin-top', '56px');
                        $('.ui-page').css('min-height','0');
                        $('#top-nav-one').hide();
                        $('#top-nav-three').hide();
                        $('.hdr-main #LangShow, .hdr-main #currencyShow, .hdr-main #clientProfilePlay').hide();                  
                    });
                }
            });            
        },
       
        importGoalViewDetails: function (ventReference) {
            // Render page
            requirejs(['views/goals/archievedGoalView'], function (GoalDetailsView) {
                var goalDetailsView = new GoalDetailsView({
                	vent: ventReference
                });
                
              $('#top-nav').hide();
              $('#top-nav-one').hide();
              $('#top-nav-two').show();
              $('.hdr-main #LangShow, .hdr-main #currencyShow, .hdr-main #clientProfilePlay').hide();
              $('#top-nav-two, .hdr-main #nameShow, .hdr-main #currencyShowNoSelect').show();
              $('main').css('margin-top', '53px');
            });
        },
        //Agenda screen handling
        ArchievedGoaldRoute: function (goalId,modify) {
            var vent = this;
            var screenID = languageBundle.screenID.GoalViewDetails.screenID;
            var codedValue = languageBundle.screenID.ConfirmTransaction.codedValues;
			var goalId = localeInformation.models[0].get('goalID');
            // Disabling the loader.
          loaderLogicEnabled = false;
          $.mobile.loading('show');
          $(".ui-loader-background").addClass('ui-loading');
            languageBundle.fetch({
                url: isDemoApp ? 'testdata/getContentAPI.json' : contextRootFull + '/content/applicationID/Citiplanner/viewID/' + screenID + '?contentType=codedValues,languageBundles&indexValue=FOREX_CCY_LIST',
                success: function () {
                    // Render page                	
                    vent.importGoalViewDetails(vent);                    
                }
            });
            // Update page title
            this.setPageTitle('GoalViewDetails');
        },
       
		 showPortfolioLongTerm: function(){
			 var t = this;
        	var screenID = 'RA23,RA24,RA25,RA26';
            var codedValue = 'FOREX_CCY_LIST';
        	this.showLoader();
            languageBundle.fetch({
                url: isDemoApp ? 'testdata/getContentAPI.json' : contextRootFull + '/content/applicationID/Citiplanner/viewID/' + screenID + '?contentType=codedValues,languageBundles&indexValue=' + codedValue,
                success: function() {
                    requirejs([
                        'views/finances/portfolioLongTermView'], function (PortfolioLongTermView) {

                        var portfolioLongTermView = new PortfolioLongTermView({
                        });




                        $('#top-nav').hide();
                        $('#top-nav-one').hide();
                        // $('#top-nav-two').show();
                        $('.hdr-main #LangShow, .hdr-main #currencyShow, .hdr-main #clientProfilePlay').hide();
                        $('#top-nav-two, .hdr-main #nameShow, .hdr-main #currencyShowNoSelect').show();
                        //$('#row2_table').hide();
                        $('.sticker-bottom').show();
                        $('main').css('margin-top', '53px');
                    }); // end requirejs
        		},
        		error: function (resp, err, options) {
        		t.hideLoader();
        		  if (err) 
               	   t.commonUtilsView.render(err, 'promptMessage');
        		},
        	});

        },
        
        // Handler to navigate to goals module.
        // Initially goes to no goals screen. If goal is present, it navigates to goal summary.
        // 1. Fetches the model files.
        loadGoal: function () {
            _.bindAll(this, 'getGoal');
            requirejs(['models/goals/goalSummaryLandingModel'], this.getGoal);
        },
        // 2. Gets the goal details from API.
        getGoal: function (GoalSummaryLandingModel) {
            // Info for language bundle request.
            var screenID = languageBundle.screenID.GoalLanding.screenID;
            var codedValue = languageBundle.screenID.GoalLanding.codedValues;
            var greetedRelationship = localeInformation.models[0].get('cloakedRelationshipNumber');
            var vent = this;
            // Initializing the models required for goals.
            goalSummaryLandingModel = new GoalSummaryLandingModel();
            goalSummaryArchivedModel = new GoalSummaryLandingModel();
            // Disabling the loader.
            loaderLogicEnabled = false;
            $.mobile.loading('show');
            $(".ui-loader-background").addClass('ui-loading');
            // Binding the model with a change event.
            var renderGoalObject = _.after(2, this.renderGoal);
            languageBundle.fetch({
                url: isDemoApp ? 'testdata/getContentAPI.json' : contextRootFull + '/content/applicationID/Citiplanner/viewID/' + screenID + '?contentType=codedValues,languageBundles&indexValue=GOAL_TYPE' + codedValue,
                // On success call view.
                success: function () {
                    // Initiate goal service request.
                    goalSummaryLandingModel.fetch({
                        url: isDemoApp ? 'testdata/goalSummary.json' : contextRootFull + '/wealth/goals/relationships/' + greetedRelationship + '?goalStatusType=All',
                        success: renderGoalObject,
                        error: function (resp, err, options) {
                            if (err) vent.commonUtilsView.render(err, 'promptMessage');
                            renderGoalObject();
                        }
                    });
                    // Initiate archived goal service request.
                    goalSummaryArchivedModel.fetch({
                        url: isDemoApp ? 'testdata/archivedGoalSummary.json' : contextRootFull + '/wealth/goals/archivedGoals/relationships/' + greetedRelationship,
                        error: function (resp, err, options) {
                            if (err) vent.commonUtilsView.render(err, 'promptMessage');
                            renderGoalObject();
                        },
                        success: renderGoalObject,
                    });
                },
                error: function (resp, err, options) {
                    if (err) vent.commonUtilsView.render(err, 'promptMessage');                    
                }
            });
        },
        // 3. Renders the goal screen on receiving the response.
        renderGoal: function () {
            // Dependency injection.
            requirejs(['views/goals/noGoalsLandingPage', 'models/goals/goalSummaryLandingModel', 'views/goals/goalSummaryLandingView'], function (NoGoalsLandingPage, GoalSummaryLandingModel, GoalSummaryLandingView) {
                var goalCount = (goalSummaryLandingModel && goalSummaryLandingModel.get('goalList') && goalSummaryLandingModel.get('goalList').goal) ? goalSummaryLandingModel.get('goalList').goal.length : 0;
                var archivedGoalCount = (goalSummaryArchivedModel && goalSummaryArchivedModel.get('goals')) ? goalSummaryArchivedModel.get('goals').length : 0;
                // Check if model has data.
                if (goalCount !== 0 || archivedGoalCount !== 0) {
                    // Load the goal summary.
                    new GoalSummaryLandingView({
                        model: goalSummaryLandingModel,
                        archivedModel: goalSummaryArchivedModel
                    });
                } else {
					if(App.CBOLChannel){
						vent.commonUtilsView.render(languageBundle.getLanguageBundle().NO_GOALS_AVAILABLE, 'promptMessage', undefined, vent.navigateToFinance);
						return;
					}
                    // Load the no goal screen.
                    new NoGoalsLandingPage();
                }
                setTimeout(function(){$('.main-nav').show().delay(0).animate({
                    'top': '56px'
                }, 100)}, 500);
                $('.hdr-main #LangShow, .hdr-main #currencyShow, .hdr-main #clientProfilePlay').hide();
                $('#top-nav-two, .hdr-main #nameShow, .hdr-main #currencyShowNoSelect').show();
                $('main').css('margin-top', '53px');
                $('#top-nav-one').hide();
               if(!App.isMobile) {
	                $('.sticker-bottom').show().delay(0).animate({
	                    'bottom': '0px'
	                }, 100);
                }
                $('.goals-icon').remove();
            });
        },
		//CBOL Flow
        navigateToFinance: function(){
        	Backbone.history.navigate('#finances', {
	        	  trigger: true
	          });
        },
        //Liquid Assets View
        showLiquidAssets: function () {
        	var t = this;
        	this.showLoader();
            var screenID = 'RA30,RA31,RA32';
            var codedValue = 'FOREX_CCY_LIST';
            languageBundle.fetch({
                url: isDemoApp ? 'testdata/getContentAPI.json' : contextRootFull + '/content/applicationID/Citiplanner/viewID/' + screenID + '?contentType=codedValues,languageBundles&indexValue=' + codedValue,
                success: function () {
                    //Render page
                    requirejs(['views/finances/liquidAssetsView', 'models/finances/liquidAssetsModel', ], function (LiquidAssetsView) {
                        var liquidAssetsView = new LiquidAssetsView({});
                        $('#top-nav').hide();
                        $('#top-nav-one').hide();
                        //$('#top-nav-two').show();
                        $('.hdr-main #LangShow, .hdr-main #currencyShow, .hdr-main #clientProfilePlay').hide();
                        $('#top-nav-two, .hdr-main #nameShow, .hdr-main #currencyShowNoSelect').show();
                        $('main').css('margin-top', '23px');
                        $('.sticker-bottom').hide();
                    });
                },
                error: function (resp, err, options) {
                	t.hideLoader();
                	  if (err) 
                   	   t.commonUtilsView.render(err, 'promptMessage');
                }
            }); // end showPage() callback function
        },
        showShortTerm: function () {
        	var t = this;
        	this.showLoader();
            var screenID = 'RA27,RA28,RA29';
            var codedValue = 'FOREX_CCY_LIST';
            languageBundle.fetch({
                url: isDemoApp ? 'testdata/getContentAPI.json' : contextRootFull + '/content/applicationID/Citiplanner/viewID/' + screenID + '?contentType=codedValues,languageBundles&indexValue=' + codedValue,
                success: function () {
                    //Render page
                    requirejs(['views/finances/portfolioShortTermView', 'highcharts'], function (PortfolioShortTermView, highcharts) {
                        new PortfolioShortTermView({});
                        $('#top-nav').hide();
                        $('#top-nav-one').hide();
                        //$('#top-nav-two').show();
                        $('.hdr-main #LangShow, .hdr-main #currencyShow, .hdr-main #clientProfilePlay').hide();
                        $('#top-nav-two, .hdr-main #nameShow, .hdr-main #currencyShowNoSelect').show();
                        $('main').css('margin-top', '53px');
                    });
                },
                error: function (resp, err, options) {
                	t.hideLoader();
                	  if (err) 
                   	   t.commonUtilsView.render(err, 'promptMessage');
                }
            }); // end showPage() callback function
        },
        
        //Finances page added by Senthil on 26102015
        showFinances: function () {
        	var t = this;
		    $('#module-section').html('');
        	this.showLoader();
			// Instantiate and fetch language bundle.
			if (languageBundle == undefined)
				languageBundle = new LanguageBundle();

            var screenID = languageBundle.screenID.Finances.screenID;
            var codedValues = "";
            //calling the agenda screen ID for CBOL Flow
            if(App.CBOLChannel){
            	screenID = languageBundle.screenID.Finances.screenID+','+languageBundle.screenID.Agenda.screenID;
            	//codedValues = 'BASE_CCY';
            }
            languageBundle.fetch({
                url: isDemoApp ? 'testdata/getContentAPI.json' : contextRootFull + '/content/applicationID/Citiplanner/viewID/' + screenID + '?contentType=codedValues,languageBundles&indexValue=FOREX_CCY_LIST,PT_DFT_SEARCH_OPT,BASE_CCY',
                success: function () {
                    // Render page
                    requirejs(['views/finances/financesView', 'models/userModel', 'models/finances/portfolioNetworthDetailsModel'], function (FinancesView, UserModel, PortfolioNetworthDetailsModel) {
                        var userModel = new UserModel();
                        //var portfolioNetworthDetailsModel = new PortfolioNetworthDetailsModel(data, {parse: true});
                        var financesView = new FinancesView({
                            userModel: userModel,
                            //financesModel: portfolioNetworthDetailsModel,
                            cmsContents: languageBundle
                        });
                        $('#top-nav').hide();
                        $('#top-nav-one').hide();
                        $('.hdr-main #LangShow, .hdr-main #currencyShow, .hdr-main #clientProfilePlay').hide();
                        $('#top-nav-two, .hdr-main #nameShow, .hdr-main #currencyShowNoSelect').show();
                        if(!App.isMobile)
                        	$('main').css('margin-top', '53px');
                        $('.sticker-bottom').hide();
                    });
                },
                error: function (resp, err, options) {
                	t.hideLoader();
                	  if (err) 
                		  t.commonUtilsView.render(err, 'promptMessage');
//                    // Render page
//                    requirejs(['views/finances/financesView', 'models/userModel', 'models/finances/portfolioNetworthDetailsModel'], function (FinancesView, UserModel, PortfolioNetworthDetailsModel) {
//                        var userModel = new UserModel();
//                        //var portfolioNetworthDetailsModel = new PortfolioNetworthDetailsModel(data, {parse: true});
//                        var financesView = new FinancesView({
//                            userModel: userModel,
//                            //financesModel: portfolioNetworthDetailsModel,
//                            cmsContents: languageBundle
//                        });
//                        $('#top-nav').hide();
//                        $('#top-nav-one').hide();
//                        $('.hdr-main #LangShow, .hdr-main #currencyShow, .hdr-main #clientProfilePlay').hide();
//                        $('#top-nav-two, .hdr-main #nameShow, .hdr-main #currencyShowNoSelect').show();
//                        $('main').css('margin-top', '53px');
//                        $('.sticker-bottom').hide();
//                    });
                },
            });
        },
		// Wealth Snapshot Added by Neeraj
		showWealthSnapshot:function(){
			var t = this;
			window.handleLoader('show');
			languageBundle = new LanguageBundle();
			var screenID = languageBundle.screenID.Finances.screenID;
			screenID = screenID + ',RA30,RA31,RA32';
			languageBundle.fetch({
				url: isDemoApp ? 'testdata/getContentAPI_New1.json' : contextRootFull + '/content/applicationID/Citiplanner/viewID/' + screenID + '?contentType=codedValues,languageBundles&indexValue=FOREX_CCY_LIST,CDI_AAI_RANGE,RA_FUND_ALERT_LEVEL,PRRTYPE,RA_CURRENCY_CLASS,DN_FUND_CLASS,FA_MOBILE_NOT_AVAILABLE,FA_EMAIL_NOT_AVAILABLE,TWA_ALERT_RECUR_OPTIONS,RA_DOC_TYPE,RA_FACT_SHEET_PREFIX,RA_MORNING_STAR_ID,RA_MORNING_STAR_ID,RA_MORNING_STAR_MARKET',
				success: function (data) {
                requirejs([
                       	'views/finances/wealthSnapshotView'
                ], function (WealthSnapshotView) {
                	new WealthSnapshotView({
                        vent: t.vent
                	});
                    
					$('#top-nav').hide();
					$('#top-nav-one').hide();
					$('.hdr-main #LangShow, .hdr-main #currencyShow, .hdr-main #clientProfilePlay').hide();
					$('#top-nav-two, .hdr-main #nameShow, .hdr-main #currencyShowNoSelect').show();
					
                    $('main').css('margin-top', '53px');
                });
				}
            });
        },
        
		showInvestmentDetails: function(){
			handleLoader('show');
        	var t = this;
			if (languageBundle == undefined)
				languageBundle = new LanguageBundle()
				var screenID = 'RA30,RA31,RA32';
    	        var codedValue = 'FOREX_CCY_LIST';
    	        languageBundle.fetch({
					url: isDemoApp ? 'testdata/getContentAPI.json' : contextRootFull + '/content/applicationID/Citiplanner/viewID/' + screenID + '?contentType=codedValues,languageBundles&indexValue=' + codedValue,
					success: function () {
    	                //Render page
						requirejs([
							'views/finances/investmentDetailsView'
						], function (investmentDetailsView) {
							new investmentDetailsView({
									vent: t.vent,
									cmsContents: languageBundle
							});
							$('#top-nav').hide();
							$('#top-nav-one').hide();
							$('.hdr-main #LangShow, .hdr-main #currencyShow, .hdr-main #clientProfilePlay').hide();
							$('#top-nav-two, .hdr-main #nameShow, .hdr-main #currencyShowNoSelect').show();
							$('main').css('margin-top', '53px');
						});
					},
					error: function(resp, err, options) {
						if(err)
							t.commonUtilsView.render(err, 'promptMessage');
					}
				}); // end showPage() callback function
		},
		
        // Links to header views
        setCommonHeaderView: function (commonHeaderView) {
            this.commonHeaderView = commonHeaderView;
        },
        setCommonHeaderOneView: function (commonHeaderOneView) {
            this.commonHeaderOneView = commonHeaderOneView;
        },
        setCommonHeaderTwoView: function (commonHeaderTwoView) {
            this.commonHeaderTwoView = commonHeaderTwoView;
        },
        setPageTitleView: function (pageTitleView) {
            this.pageTitleView = pageTitleView;
            if (this.pageTitleCached) {
                // Set the last cached page title
                this.pageTitleView.setPageTitle(this.pageTitleCached);
                delete(this.pageTitleCached);
            }
        },
        setPageTitle: function (pageTitle) {
            if (this.pageTitleView) {
                this.pageTitleView.setPageTitle(pageTitle);
            } else {
                // Remember page title to set, once the
                // the page title view is provided
                this.pageTitleCached = pageTitle;
            }
        },
        //Sticky Footer
        setStickyNavView: function (stickyNavView) {
            this.stickyNavView = stickyNavView;
        },
        // Venkatesh: To navigate to overall portfolio
        showOverallPortfolio: function () {
        	this.showLoader();
            var vent = this;
            var screenID = 'RA22';
            // Fetch content
            languageBundle.fetch({
                url: isDemoApp ? 'testdata/getContentAPI.json' : contextRootFull + '/content/applicationID/Citiplanner/viewID/' + screenID + '?contentType=codedValues,languageBundles&indexValue=FOREX_CCY_LIST',
                success: vent.loadOverallPortfolio,
                error: function (resp, err, options) {
                	vent.hideLoader();
                	  if (err) 
                		  vent.commonUtilsView.render(err, 'promptMessage');
                }
            });
        },
        // Venkatesh: Loads the overall portfolio.
        loadOverallPortfolio: function () {
            requirejs(['views/finances/overallPortfolioView'], function (OverallPortfolioView) {
                new OverallPortfolioView();
            });
            $('#top-nav').hide();
            $('#top-nav-one').hide();
            $('.hdr-main #LangShow, .hdr-main #currencyShow, .hdr-main #clientProfilePlay').hide();
            $('#top-nav-two, .hdr-main #nameShow, .hdr-main #currencyShowNoSelect').show();
            $('main').css('margin-top', '23px');
            $('.sticker-bottom').show();
        },

        //Agenda screen handling
        ArchievedGoaldRoute: function (goalId,modify) {
            var vent = this;
            var screenID = languageBundle.screenID.GoalViewDetails.screenID;
            var codedValue = languageBundle.screenID.ConfirmTransaction.codedValues;
			var goalId = localeInformation.models[0].get('goalID');
            // Disabling the loader.
          loaderLogicEnabled = false;
          $.mobile.loading('show');
          $(".ui-loader-background").addClass('ui-loading');
            languageBundle.fetch({
                url: isDemoApp ? 'testdata/getContentAPI.json' : contextRootFull + '/content/applicationID/Citiplanner/viewID/' + screenID + '?contentType=codedValues,languageBundles&indexValue=FOREX_CCY_LIST',
                success: function () {
                    // Render page                	
                    vent.importGoalViewDetails(vent);                    
                }
            });
            // Update page title
            this.setPageTitle('GoalViewDetails');
        },        
		
        showConfirmDialog: function (data, callback) {
            requirejs([
                'views/shell/confirmModalView'
            ], function (ConfirmModalView) {

                this.confirmModalView = new ConfirmModalView({
                    data: data,
                    callback: callback
                });

                this.confirmModalView.$el = this.$('#commonModalPop');
                this.confirmModalView.render(data);
                this.confirmModalView.delegateEvents();
                $('#modal-container-confirm').modal('show');


            });
        },
		 
        showLoader: function(){
        	$.mobile.loading('show');
            $(".ui-loader-background").addClass('ui-loading');
            loaderLogicEnabled=false;
        },
        hideLoader: function(){
        	$.mobile.loading('hide');
            $(".ui-loader-background").removeClass('ui-loading');
            loaderLogicEnabled=true;
        },
        
        // Links to header views
        setCommonHeaderView: function (commonHeaderView) {
            this.commonHeaderView = commonHeaderView;
        },
        setCommonHeaderOneView: function (commonHeaderOneView) {
            this.commonHeaderOneView = commonHeaderOneView; 
        },
        setCommonHeaderTwoView: function (commonHeaderTwoView) {
            this.commonHeaderTwoView = commonHeaderTwoView;
        },
        setPageTitleView: function (pageTitleView) {
            this.pageTitleView = pageTitleView;

            if (this.pageTitleCached) {
                // Set the last cached page title
                this.pageTitleView.setPageTitle(this.pageTitleCached);
                delete(this.pageTitleCached);
            }
        },
        setPageTitle: function (pageTitle) {
            if (this.pageTitleView) {
                this.pageTitleView.setPageTitle(pageTitle);
            } else {
                // Remember page title to set, once the
                // the page title view is provided
                this.pageTitleCached = pageTitle;
            }
        },
		
        //Sticky Footer
        setStickyNavView: function (stickyNavView) {
            this.stickyNavView = stickyNavView;
        } ,
        //Finances Insurance Tab
        financeInsurance: function () {
            this.showLoader();
            var _this = this;
            var screenID = languageBundle.screenID.FinanceInsurance.screenID;
            var codedValue = languageBundle.screenID.FinanceInsurance.codedValues;
            languageBundle.fetch({
                url: isDemoApp ? 'testdata/getContentAPI.json' : contextRootFull + '/content/applicationID/Citiplanner/viewID/' + screenID + '?contentType=codedValues,languageBundles&indexValue=' + codedValue,
                success: function () {
                    //Render page
                    requirejs(['views/finances/financeInsurance', 'models/finances/insuranceHoldingMainModel'], function (FinanceInsurance, InsuranceHoldingMainModel) {
                        var insuranceHoldingMainModel = new InsuranceHoldingMainModel({
                        			portfolioFromDate : localeInformation.models[0].get('portfolioFromDate'),
                        			portfolioToDate : localeInformation.models[0].get('portfolioToDate'),
                        			cloakedrelationNo : localeInformation.models[0].get('cloakedRelationshipNumber')
                        		});
                        insuranceHoldingMainModel.fetch({
                            success: function (insuranceResp) {
                                new FinanceInsurance({
                                    languageBundle: languageBundle,
                                    insuranceResp: insuranceResp
                                });
                                $('#top-nav').hide();
                                $('#top-nav-one').hide();
                                //$('#top-nav-two').show();
                                $('.hdr-main #LangShow, .hdr-main #currencyShow, .hdr-main #clientProfilePlay').hide();
                                $('.finances-wrapper, #top-nav-two, .hdr-main #nameShow, .hdr-main #currencyShowNoSelect').show();
                                $('main').css('margin-top', '23px');
                                $('.finances-wrapper').css('bottom', '0');
                                $('.sticker-bottom').hide();
                                $('.session-id').hide(); //Added code for SESSION_ID implementation
                                _this.hideLoader();
                            },
                            error: function (resp, err, options) {
                            	_this.hideLoader();
 		   	                    if (err) 
 		   	                    	_this.commonUtilsView.render(err, 'promptMessage'); 		   	                    
 		   	                }
                        });
                    });
                    _this.hideLoader();
                },
                error: function (resp, err, options) {
                    _this.hideLoader();
                    if (err) 
                    	_this.commonUtilsView.render(err, 'promptMessage');
                }
            }); // end showPage() callback function
        },
		showMACDeposits: function () {
	        	this.showLoader();
	        	var t = this;
	            var screenID = 'RA30,RA31,RA32';
	            var codedValue = 'FOREX_CCY_LIST';
	            /*languageBundle.fetch({
	                url: isDemoApp ? 'testdata/getContentAPI.json' : contextRootFull + '/content/applicationID/Citiplanner/viewID/' + screenID + '?contentType=codedValues,languageBundles&indexValue=' + codedValue,
	                success: function () {
	                    //Render page
	                    requirejs(['views/finances/multiAssetClass/macDepositsView', 'models/finances/liquidAssetsModel', ], function (macDepositsView) {
	                        var macDepositsView = new macDepositsView({});
	                        $('#top-nav').hide();
	                        $('#top-nav-one').hide();
	                        //$('#top-nav-two').show();
	                        $('.hdr-main #LangShow, .hdr-main #currencyShow, .hdr-main #clientProfilePlay').hide();
	                        $('#top-nav-two, .hdr-main #nameShow, .hdr-main #currencyShowNoSelect').show();
	                        $('main').css('margin-top', '54px');
	                        $('.sticker-bottom').hide();
	                        $('.session-id').hide();//Added code for SESSION_ID implementation
	                        t.hideLoader();
	                    });
	                },
	                error: function(resp, err, options) {
     					 if(err)
     						t.commonUtilsView.render(err, 'promptMessage');
     		         }
	            }); // end showPage() callback function
*/	

                //Render page
                requirejs(['views/finances/multiAssetClass/macDepositsView', 'models/finances/liquidAssetsModel', ], function (macDepositsView) {
                    var macDepositsView = new macDepositsView({});
                    $('#top-nav').hide();
                    $('#top-nav-one').hide();
                    //$('#top-nav-two').show();
                    $('.hdr-main #LangShow, .hdr-main #currencyShow, .hdr-main #clientProfilePlay').hide();
                    $('#top-nav-two, .hdr-main #nameShow, .hdr-main #currencyShowNoSelect').show();
                    $('main').css('margin-top', '54px');
                    $('.sticker-bottom').hide();
                    $('.session-id').hide();//Added code for SESSION_ID implementation
                   // t.hideLoader();
                });
            
	            },
				
				showMACLoans:function(){
				var t = this;
				handleLoader('show');
                requirejs([
                       	'views/finances/multiAssetClass/macLoansView'
                ], function (macLoansView) {
                	new macLoansView({
                        vent: t.vent,
                	});                    
                    $('#top-nav').hide();
                    $('#top-nav-one').hide();
                    $('#top-nav-two').show();
                    $('.hdr-main #LangShow, .hdr-main #currencyShow, .hdr-main #clientProfilePlay').hide();
                    $('#top-nav-two, .hdr-main #nameShow, .hdr-main #currencyShowNoSelect').show();
                    $('main').css('margin-top', '54px');
                });
	        },
			 showMACInsurance: function () {
            this.showLoader();
            var _this = this;
            var screenID = languageBundle.screenID.FinanceInsurance.screenID;
            var codedValue = languageBundle.screenID.FinanceInsurance.codedValues;
                    var encryptedRelnList = localeInformation.models[0].get('relnListEncrypted')?localeInformation.models[0].get('relnListEncrypted').toString():'';
                	var portfolioFromDateIns = localeInformation.models[0].get('portfolioFromDateToAPI');
        			var portfolioToDateIns = localeInformation.models[0].get('portfolioToDate');
        			var sinceInitialIns = localeInformation.models[0].get('initialInvestment') ? 'Y' : 'N'; 
                    //Render page
                    requirejs(['views/finances/multiAssetClass/macInsuranceView','models/finances/insuranceNeedsModel'], 
					function (MACInsurance,InsuranceNeedsModel) {  
                    			new MACInsurance({
                                    languageBundle: languageBundle,
                                });
                                $('#top-nav').hide();
                                $('#top-nav-one').hide();
                                //$('#top-nav-two').show();
                                $('.hdr-main #LangShow, .hdr-main #currencyShow, .hdr-main #clientProfilePlay').hide();
                                $('.finances-wrapper, #top-nav-two, .hdr-main #nameShow, .hdr-main #currencyShowNoSelect').show();
                                $('main').css('margin-top', '54px');
                                $('.finances-wrapper').css('bottom', '0');
                                $('.sticker-bottom').hide();
                                $('.session-id').hide(); //Added code for SESSION_ID implementation
                    });
         },
    });
    return AppRouter;
});