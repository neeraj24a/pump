requirejs.config({
    // Shims for libs that don't conform to RequireJS's AMD module pattern
    shim: {
        "bootstrap": {
            deps: ['jquery']
        },
        "common": {
            deps: ['jquery']
        },
		"stickykit": {
			deps: ['jquery']
		},
		"screenfull": {
			deps: ['jquery']
		},
		"owl": {
			deps: ['jquery']
		}
    },
    waitSeconds: 0,
    // Paths to libraries
    paths: {
        templates: '../templates',
        text: 'libs/requirejs-text/text',
        jquery: 'libs/jquery/jquery',
        bootstrap: 'libs/bootstrap/bootstrap',
        handlebars: 'libs/handlebars/handlebars',
        moment: 'libs/moment/moment', 
        underscore: 'libs/underscore/underscore',
        backbone: 'libs/backbone/backbone',
        icheck: 'libs/icheck/icheck',
        iScroll:'libs/iscroll/iScroll',
        stikyfill:'libs/Stickyfill/dist/stickyfill',
		stickykit:'libs/sticky-kit/stickykit',
		screenfull: 'libs/screenfull/dist/screenfull',
		owl:'libs/owl/owl'
    }
});

requirejs(['vmain']);
