/*
	Miscellaneous debug-related utility functions.
*/
define(
[
	'jquery'
],
function($){
	"use strict";

	var exports = {};

	var cols = 12;

	function generateGridDom(){
	
		var container = document.createElement('div');
		container.className = 'container-fluid';
		container.id = 'debug-cols';
		
		var row = document.createElement('div');
		row.className = 'row';
		
		for( var i=0; i<cols; ++i ){
			var col = document.createElement('div');
			col.className = 'col-xs-1';
			row.appendChild( col );
		}
		
		container.appendChild( row );
		
		return container;
	}

	var gridAdded = false;
	var isVisible = false;
	
	function addGrid(){
		if( ! gridAdded ){
			$('body').append( generateGridDom() );
			gridAdded = true;
		}
	}
	
	
	exports.showGrid = function(){
		addGrid();
	
		$('#debug-cols').show();
		isVisible = true;
	};

	
	exports.hideGrid = function(){
		$('#debug-cols').hide();
		isVisible = false;
	};

	
	exports.toggleGrid = function(){
		if( isVisible ){
			exports.hideGrid();
		}
		else{
			exports.showGrid();
		}
	};


	return exports;

});
