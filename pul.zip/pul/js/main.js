var App = App || {};
App.isMobile= (function(){
	if(window.innerWidth <= 420) {
		return false;
	}
	else{
		return false;
	}
})();

// Start main app logic...
requirejs([
        'jquery',
		'backbone',
        'router',
        'common',
        'vHelper',
        'models/userModel',
        'views/shell/commonHeaderView',
        'views/shell/navView',
        'views/shell/pageTitleView',
        'views/common/loaderView',
		'mainExecutor',
        'views/uiLib/DataFormatterutil',
		'views/uiLib/handlebarsHelpers',
        'views/uiLib/globalVariableInitiation',
        ],
    function($, Backbone, AppRouter, commonjs, vhelper, UserModel, CommonHeaderView, NavView, PageTitleView, LoaderView,Executor) {
		Executor.execute.apply(this, [$, Backbone, AppRouter, commonjs, vhelper, UserModel, CommonHeaderView, NavView, PageTitleView, LoaderView]);        
    });