//variable to store cbol response.
var isDemoApp = true;
var contextRootFull = window.location.pathname.substring(0, window.location.pathname.indexOf("/",2));
var App = App || {};

//Handle the window close / browser back button events
App.vHelper = function(){
	console.log("loaded");
	retreiveVData();
}
	

if(self && self !== undefined){
	try{
		if( self == top ) {
			document.documentElement.style.display = 'block' ;
		}
		else {
			top.location = self.location ;
		}
	}
	catch(e){
		console.log("catch exception" +e);
	}
}

function retreiveVData(){
	console.log('session API request');
	$.ajax({
		url: isDemoApp ? 'testdata/user.json' : contextRootFull+'/service/get-user',
		type: 'GET',
		success: function(resp){
			resp = $.parseJSON(resp);
			//Null check for response
			if(resp && resp.user && Object.keys(resp.user).length > 0){
				userInfo = resp.user;
				cloakedCustomerID = resp.cloakedCustomerID;
				requirejs(['collections/common/localeInfo'], function(localeInfo) {
					localeInformation = new localeInfo();
					localeInformation.fetch({
						success: function() {
							if(userInfo){
								localeInformation.models[0].set('fname', userInfo.fname);
								localeInformation.models[0].set('lname', userInfo.fname);
								localeInformation.models[0].set('username' , userInfo.username);
								localeInformation.models[0].set('user_id' , userInfo.id);
								if(userInfo.isPaid == "true"){
									localeInformation.models[0].set('isPaid' , true);
									userInfo.isPaid = true;
								} else {
									localeInformation.models[0].set('isPaid' , false);
									userInfo.isPaid = false;
								}
							} else {
								localeInformation.models[0].set('fname', "");
								localeInformation.models[0].set('lname', "");
								localeInformation.models[0].set('username' , "");
								localeInformation.models[0].set('user_id' , false);
								localeInformation.models[0].set('isPaid' , false);
							}
							window.location.href = '#home';
						},
						error:  function(err){
							
							console.log(err);
						}
					});
				});
			}
		},
		error: function(err){
			
			window.location.href=contextRootFull + "/html/ErrorPage.html";
		}
	});
}