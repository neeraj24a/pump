define([], function() {
	
	var Executor =
		{
		execute: function($, Backbone, AppRouter, commonjs, vhelper, UserModel, CommonHeaderView, NavView, PageTitleView, LoaderView) {
        // Fetch user data immediately
        var userModel = new UserModel();
		var vent = _.extend({}, Backbone.Events);
		Number.prototype.toMoneyFormat = function(n, x) {
		    var re = '(\\d)(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\.' : '$') + ')';
		    return this.toFixed(Math.max(0, ~~n)).replace(new RegExp(re, 'g'), '$1,');
		}

        var appRouter = new AppRouter({vent:vent});
        
        // Default loader shown during navigation.
        appRouter.on('route', function(route, params) {        	
			
        });
        
     // Default loader shown during ajax calls.
        $.ajaxSetup({
            beforeSend: function(xhr) {
            	console.log('Before send main.js: ' + App.vToken);
            	xhr.setRequestHeader('X-CSRF-TOKEN', App.vToken);
            	xhr.setRequestHeader('Content-Type', 'application/json; charset=UTF-8');    
            	/*if(loaderLogicEnabled){
	                $.mobile.loading('show');
	                $(".ui-loader-background").addClass('ui-loading');
            	}*/
            },
            complete: function(resp) {
            	if(resp.getResponseHeader('X-CSRF-TOKEN'))
            		App.vToken = resp.getResponseHeader('X-CSRF-TOKEN');
            	/*if(loaderLogicEnabled){
	                $.mobile.loading('hide');
	                $(".ui-loader-background").removeClass('ui-loading');
            	}*/
            }
        });
		App.vHelper();
        Backbone.history.start({
            pushState: false,
            root: window.location.pathname,
            silent: false
        });
        
        $.fn.serializeObject = function () {
            var o = Object.create(null),
                    elementMapper = function (element) {
                        element.name = $.camelCase(element.name);
                        return element;
                    },
                    appendToResult = function (i, element) {
                        var node = o[element.name];
                        if ('undefined' != typeof node && node !== null) {
                            o[element.name] = node.push ? node.push(element.value) : [node, element.value];
                        } else {
                            o[element.name] = element.value;
                        }
                    };
            $.each($.map(this.serializeArray(), elementMapper), appendToResult);
            return o;
        };

        /*
        	Init stuff when page DOM has loaded...
        */
        $(function() {

            //*******************Script to make the Model Dialog in Center ***************//
            function setModalMaxHeight(element) {
                this.$element = $(element);
                var dialogMargin = $(window).width() > 767 ? 62 : 22;
                var contentHeight = $(window).height() - dialogMargin;
                var headerHeight = this.$element.find('.modal-header').outerHeight() || 2;
                var footerHeight = this.$element.find('.modal-footer').outerHeight() || 2;
                var maxHeight = contentHeight - (headerHeight + footerHeight);

                this.$element.find('.modal-content').css({
					'overflow': 'hidden'
				});

                this.$element.find('.modal-body').css({
					'max-height': maxHeight,
					'overflow-y': 'auto'
				});
            }

            $('.modal').on('show.bs.modal', function() {
                $(this).show();
                setModalMaxHeight(this);
            });

            $(window).resize(function() {
                if ($('.modal.in').length != 0) {
                    setModalMaxHeight($('.modal.in'));
                }
            });
        });
		
		}
	}
	return Executor;
	
});