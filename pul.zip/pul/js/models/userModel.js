/*
	User model.
*/
define(['backbone'], function(Backbone){

	"use strict";

	var UserModel = Backbone.Model.extend({
		url: isDemoApp ? 'testdata/user.json' : contextRootFull+'/service/get-user',
	});


	return UserModel;

});
