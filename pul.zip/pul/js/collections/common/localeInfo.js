/* Model used to handle Locale info across Citiplanner.
   This model is instantiated only once and the same reference is throughout.  
   Created by Venkat on 23-Oct
*/
define(['backbone'], function (Backbone) {
    "use strict";
	console.log(isDemoApp);
    return Backbone.Collection.extend({
        url: isDemoApp ? 'testdata/localeinfo.json' : contextRootFull + '/testdata/localeinfo.json',
		//url: 'testdata/localeinfo.json',
    });
});