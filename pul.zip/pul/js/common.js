/*
@var isDemoApp	-	Enable it to true for local environment.
*/
var isDemoApp = true;
var loaderLogicEnabled = true;
var contextRootFull = window.location.pathname.substring(0, window.location.pathname.indexOf("/",2));
var languageBundle, localeInformation;
var idleTimer = undefined;
var popupTimer = undefined;
var userInfo = "";
// Override the existing window.open to control stuffs in one place.
window.open = function (open) {
    return function (url, name, params) {
    	if (typeof params == 'undefined') {
    		params = 'height=' + screen.height + ',width=' + screen.width + ',scrollbars=yes,location=yes,resizable=yes';
    	}
        return open.call(window, url, name, params);
    };
}(window.open);
// End.

//LV Controls Predefined
//Avoid `console` errors in browsers that lack a console.
(function() {
	var method;
	var noop = function () {};
	var methods = [
	  'assert', 'clear', 'count', 'debug', 'dir', 'dirxml', 'error',
	  'exception', 'group', 'groupCollapsed', 'groupEnd', 'info', 'log',
	  'markTimeline', 'profile', 'profileEnd', 'table', 'time', 'timeEnd',
	  'timeline', 'timelineEnd', 'timeStamp', 'trace', 'warn'
	];
	var length = methods.length;
	var console = (window.console = window.console || {});

	while (length--) {
		method = methods[length];
		//Only stub undefined methods.
		if (!console[method]) {
			console[method] = noop;
		}
	}
}());



//Prevent the backspace key from navigating back.
$(document).unbind('keydown').bind('keydown', function (event) {
    var doPrevent = false;
    if (event.keyCode === 8) {
        var d = event.srcElement || event.target;
        if ((d.tagName.toUpperCase() === 'INPUT' && 
             (
                 d.type.toUpperCase() === 'TEXT' ||
                 d.type.toUpperCase() === 'PASSWORD' || 
                 d.type.toUpperCase() === 'FILE' || 
                 d.type.toUpperCase() === 'SEARCH' || 
                 d.type.toUpperCase() === 'EMAIL' || 
                 d.type.toUpperCase() === 'NUMBER' || 
                 d.type.toUpperCase() === 'DATE' )
             ) || 
             d.tagName.toUpperCase() === 'TEXTAREA') {
            doPrevent = d.readOnly || d.disabled;
        }
        else {
            doPrevent = true;
        }
    }

    if (doPrevent) {
        event.preventDefault();
    }
});

//Preventing the page submit on click of enter key
$(document).keypress(
    function(event){
     if (event.keyCode == '13') {
        event.preventDefault();
      }
});

function setCookie(cname, cvalue, exdays) {
	var d = new Date();
	d.setTime(d.getTime() + (exdays*24*60*60*1000));
	var expires = "expires="+d.toUTCString();
	document.cookie = cname + "=" + cvalue + "; " + expires;
}

function getCookie(cname) {
	var name = cname + "=";
	var ca = document.cookie.split(';');
	for(var i=0; i<ca.length; i++) {
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1);
		if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
	}
	return "";
}

function deleteCookie(cookiename) {
	var d = new Date();
	d.setDate(d.getDate() - 1);
	var expires = ";expires="+d;
	var name=cookiename;
	var value="";
	document.cookie = name + "=" + value + expires + "; path=";                    
}

//entitlement check for modules
function entitlementCheck(moduleName){
	var name = "entitlementList" + "=";
	var ca = document.cookie.split(';');
	var entitlement = "";
	for(var i=0; i<ca.length; i++) {
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1);
		if (c.indexOf(name) == 0) { entitlement = c.substring(name.length,c.length)}
	}
	return (entitlement && entitlement.split(',').indexOf(entitlementList[moduleName]) > -1) ?  "Y" :  "N" ;
}

// Added by Venkat.
// Shows/hides the loading icon.
function handleLoader(args) {
	if(args === 'show') {
		if(App && App.isMobile){
			//Call loader of MBOL
			blockPage();
		} else {
			$.mobile.loading('show');
	        $(".ui-loader-background").addClass('ui-loading');
	        loaderLogicEnabled = false;
		}
	}
	else {
		if(App && App.isMobile){
			unblockUI();
		} else {
			 $.mobile.loading('hide');
	         $(".ui-loader-background").removeClass('ui-loading');
	         loaderLogicEnabled = true;
		}
	}
}
