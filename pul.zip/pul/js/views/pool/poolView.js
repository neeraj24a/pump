define([
    'jquery',
    'handlebars',
    'backbone',
    'text!templates/pool/poolView.tpl',
	'text!templates/pool/sideBarView.tpl',
	'text!templates/pool/mobileNavView.tpl',
	'text!templates/pool/poolBodyView.tpl',
	'text!templates/pool/poolFooter.tpl',
	'text!templates/pool/searchView.tpl',
	'text!templates/pool/socialShareView.tpl',
	'text!templates/pool/switcherView.tpl',
	'owl'], function (
	$, 
	Handlebars, 
	Backbone, 
	rawTemplate, 
	sideBarViewTemplate, 
	mobileNavTemplate, 
	poolBodyTemplate,
	poolFooterTpl,
	searchTpl,
	socialTpl,
	switcherTpl
	) {
    var poolView = Backbone.View.extend({
        el: '#app',
        template: Handlebars.compile(rawTemplate),
		initialize: function () {
			this.render();
        },
		events: {
			
		},
        render: function () {
			
            var userData = {user: userInfo};
			Handlebars.registerPartial("sidebar", sideBarViewTemplate);
			Handlebars.registerPartial("mobile", mobileNavTemplate);
			Handlebars.registerPartial("body", poolBodyTemplate);
			Handlebars.registerPartial("search", searchTpl);
			Handlebars.registerPartial("switcher", switcherTpl);
			Handlebars.registerPartial("share", socialTpl);
			Handlebars.registerPartial("footer", poolFooterTpl);
			this.$el.html(this.template(userData));
			
			this.carousel();
        },
		carousel: function(){
			
			$("#poolCarousel").owlCarousel({
				navigation : true, 
				loop: true,
				autoplay: true,
				items: 1,
				responsiveClass:true,
			});
			
			$("#trendingCarousel").owlCarousel({
				navigation : false, 
				autoplay: true,
				items: 3,
				loop:true,
				margin:10,
				responsiveClass:true,
				responsive:{
					0:{
						items: 2
					},
					543:{
						items: 3
					}
				}
			});
			
		},
		gotoPool: function(){
			window.location.href = "#pool";
		}
		
    });
    return poolView;
});