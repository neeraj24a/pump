define([
    'jquery',
    'handlebars',
    'backbone',
    'text!templates/pool/poolView.tpl',
	'text!templates/pool/sideBarView.tpl',
	'text!templates/pool/mobileNavView.tpl',
	'text!templates/pool/poolBodyView.tpl',
	'text!templates/pool/poolFooter.tpl',
	'text!templates/pool/searchView.tpl',
	'text!templates/pool/socialShareView.tpl',
	'text!templates/pool/switcherView.tpl',
	'owl'], function (
	$, 
	Handlebars, 
	Backbone, 
	rawTemplate, 
	sideBarViewTemplate, 
	mobileNavTemplate, 
	poolBodyTemplate,
	poolFooterTpl,
	searchTpl,
	socialTpl,
	switcherTpl
	) {
    var poolView = Backbone.View.extend({
        el: '#app',
        template: Handlebars.compile(rawTemplate),
		initialize: function () {
			this.render();
        },
		events: {
			
		},
        render: function () {
			
            var userData = {user: userInfo};
			Handlebars.registerPartial("sidebar", sideBarViewTemplate);
			Handlebars.registerPartial("mobile", mobileNavTemplate);
			Handlebars.registerPartial("body", poolBodyTemplate);
			Handlebars.registerPartial("search", searchTpl);
			Handlebars.registerPartial("switcher", switcherTpl);
			Handlebars.registerPartial("share", socialTpl);
			Handlebars.registerPartial("footer", poolFooterTpl);
			this.$el.html(this.template(userData));
			
			//this.carousel();
        },
		carousel: function(){
			
			$("#owlCarousel").owlCarousel({
				navigation : false, 
				slideSpeed : 300,
				paginationSpeed : 400,
				singleItem: true,
				pagination: false,
				rewindSpeed: 500
			});
			
		},
		gotoPool: function(){
			window.location.href = "#pool";
		}
		
    });
    return poolView;
});