/*
 View for "Login Panel" section on Login page
 */
define([
  'handlebars',
  'backbone',
  'text!templates/common/loaderView.tpl',
  'jquery',
], function (Handlebars, Backbone, rawTemplate, $) {
    // TODO: Remove this hack!
    // Count instances of LoginView
    var counter = 0;
    // Create backbone view that displays the Login Page HTML
    var LoaderView = Backbone.View.extend({
        el: '#module-section',
        template: Handlebars.compile(rawTemplate),
        events: {},
        initialize: function (options) {
            this.render();
        },
        render: function () {
            // Update HTML with rendered template
            this.$el.html(this.template());
            return this;
        }
    });
    return LoaderView;
});