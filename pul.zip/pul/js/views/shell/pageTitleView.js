/*
	View representing per-page title & navigation bar.
	
	Normally, it just displays page title & back button. However,
	on longer pages with several sections, it may also include
	controls to jump between page sections.

*/
define([
	'backbone',
	'handlebars',
	'text!templates/shell/pageTitleView.tpl'
], function (Backbone, Handlebars, rawTemplate) {
    "use strict";
    // Class for PageTitle view
    var PageTitleView = Backbone.View.extend({
        el: '#page-title',
        template: Handlebars.compile(rawTemplate),
        events: {
            'click .back-button': 'navigateBack',
        },
        initialize: function (options) {
            //console.log("PageTitle.initialise() called");
            this.pageTitle = options.pageTitle;
            this.commonHeaderView = options.commonHeaderView;
            this.render();
        },
        render: function () {
            // Update DOM with model data
            //console.log("PageTitle.render() called");
            /*
            // Disabling since this is not used in POC 2.

            var context = {
            	pageTitle: this.pageTitle,
            };


            this.$el.html( this.template(context) );
			
            // Update top margin via CommonHeaderView
            // This is because the PageTitleView sits within the
            // <header> element and therefore can affect its
            // height, which could conflict with the sticky
            // header setting, if this function is not
            // called.
            this.commonHeaderView.updateMainTopMargin();
            */
            // Return self for chaining
            return this;
        },
        setPageTitle: function (pageTitle) {
            //console.log('New page title: ' + pageTitle);
            this.pageTitle = pageTitle;
            this.render();
        },
        navigateBack: function () {
            console.log('Back button clicked!');
            window.history.back();
        }
    });
    return PageTitleView;
});