/*
	The main navigation menu.

*/
define([
	'backbone',
	'handlebars',
	'jquery',
	'text!templates/shell/navView.tpl',
	'debug'
], function (Backbone, Handlebars, $, rawTemplate) {
    "use strict";
    // Class for NavView view
    var NavView = Backbone.View.extend({
        el: '#main-nav',
        template: Handlebars.compile(rawTemplate),
        events: {
            'click a': 'linkClicked',
        },
        initialize: function (options) {
            //console.log("NavView.initialise() called");
            this.navLinks = options.navLinks;
            this.devNavLinks = options.devNavLinks;
            this.commonHeaderView = options.commonHeaderView;
            this.render();
        },
        render: function () {
            // Update DOM with model data
            //console.log("NavView.render() called");
            var context = {
                navLinks: this.navLinks,
                devNavLinks: this.devNavLinks,
            };
            this.$el.html(this.template(context));
            // Return self for chaining
            return this;
        },
        clearActiveClass: function () {
            // Make all links inactive
            this.$('li').removeClass('active');
        },
        linkClicked: function (e) {
            console.log('Nav link clicked: ' + e.target.href);
            // close nav menu
            this.commonHeaderView.closeNav();
            // Make only this link active
            this.clearActiveClass();
            $(e.target).parent().addClass('active');
        },
    });
    return NavView;
});