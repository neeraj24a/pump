/*
The common page header.

 */
define([
		'backbone',
		'handlebars',
		'jquery',
		'text!templates/common/mobileHeaderView.tpl'
	],
	function (
		Backbone,
		Handlebars,
		$,
		mobileHeaderViewRaw) {

	"use strict";

	// Class for CommonHeaderView view
	var MobileNavigationHeader = Backbone.View.extend({
			el : '#mobile-viewID',

			events : {
				'click #financesTab': function () {
	                this.showPage('finances');
	            },
	            'click #overallTab': function () {
	                this.showPage('overall_portfolio');
	            },
				'click #longTermTab': function () {
	                this.showPage('portfolio_long_term');
	            },
				'click #shortTearmTab': function () {
	                this.showPage('portfolio_short_term');
	            },
				'click #liquidAssetsTab': function () {
	                this.showPage('liquid_assets');
	            },
				'click #insuranceTab': function () {
	                this.showPage('finance_insurance');
	            },
				'click #goalsTab': function () {
	                this.showPage('goals');
	            },
			},

			mobileHeaderViewTemplate : Handlebars.compile(mobileHeaderViewRaw),
			initialize: function(options){
				$(this.el).off();
				this.render();
			},
			showPage: function(routeName){
				 Backbone.history.navigate('#' + routeName, {
		                trigger: true
		            });
			},
			render : function () {
				var t = this;
				var myString = window.location.href;
				var arr = myString.split('#');
				console.log(myString);
				var pageLocation = "";

				switch (arr[1]) {
				case "agenda":
					pageLocation = "Agenda";
					break;
				case "finances":
					pageLocation = "Finances";
					break;
				case "overall_portfolio":
					pageLocation = "Portfolio Overall";
					break;
				case "portfolio_long_term":
					pageLocation = "Portfolio Long Term";
					break;
				case "portfolio_short_term":
					pageLocation = "Portfolio Short Term";
					break;
				case "liquid_assets":
					pageLocation = "Liquid Assets";
					break;
				case "finance_insurance":
					pageLocation = "Insurance";
					break;
				case "goals":
					pageLocation = "Goals";
					break;
				}
				console.log(arr[1]);
				console.log(pageLocation);
				this.$el.html(this.mobileHeaderViewTemplate({
						pageLocation : pageLocation,
						content: languageBundle.getLanguageBundle()
					}));
				this.$("#mobileNavigation").click(function () {
					$(".ui-loader-background").css("z-index", "99").css("margin-top", "150px");
            		if (!$(".ui-loader-background").hasClass("ui-loading")) {
            			$(".ui-loader-background").addClass('ui-loading');
            		} else {
            			$(".ui-loader-background").removeClass('ui-loading');
            		}
            	});
				// Return self for chaining
				return this;
			},
		});

	return MobileNavigationHeader;
});
