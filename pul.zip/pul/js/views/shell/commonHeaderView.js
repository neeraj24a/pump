/*
	The common page header.

*/
define([
	'backbone',
	'handlebars',
	'jquery',
	'text!templates/shell/commonHeaderView.tpl',
	'debug'
], function (Backbone, Handlebars, $, rawTemplate, DebugUtils) {
    "use strict";
    /*
    	Stuff for making the <header> section sticky
    */
    var isHeaderSticky = false;
    var previousMainTopMargin = 0;
    var updateMainTopMarginTimeoutID;
    // Class for CommonHeaderView view
    var CommonHeaderView = Backbone.View.extend({
        el: '#top-nav',
        events: {
            'click .nav-toggle': 'toggleNav',
            'click .debug-grid-toggle': 'toggleGrid',
        },
        template: Handlebars.compile(rawTemplate),
        initialize: function (options) {
            //console.log("CommonHeaderView.initialise() called");
			this.model = options;
            //this.listenTo(this.model, 'sync change', this.render);
            this.render();
            // Setup header to go sticky asap
        //    this.setupStickyHeader();
        },
        render: function () {
            // Update DOM with model data
            var context = {
                user: this.model,
            };
			console.log(context);
            this.$el.html(this.template(context));
            // Update top margin
            this.updateMainTopMargin();
            // Return self for chaining
            return this;
        },
        // UI Functionality
        /*
        	Opens or closes the left-hand navigation links.

        	This function simply toggles the 'nav-open' class
        	on the <body> element. The animation of the nav
        	pushing in from the left is done in CSS.
        */
        toggleNav: function () {
            $('body').toggleClass('nav-open');
        },
        /*
        	Closes the left-hand navigation links.
        */
        closeNav: function () {
            $('body').removeClass('nav-open');
        },
        /*
        	Toggles the debug grid overlay
        */
        toggleGrid: function () {
            DebugUtils.toggleGrid();
        },
        /*
        	Measures the height of the <header> element and sets the
        	top margin of <main> to be the same so that the contents
        	of <main> are never obscured by <header> while it is
        	sticky.

        	If the header is not sticky, the top magin of <main> will
        	be set to zero.
        */
        updateMainTopMargin: function () {
            //console.log('updateMainTopMargin');
            if (isHeaderSticky) {
                // measure header's height
                var headerHeight = $('header').outerHeight(true);
                // check if current header height differs from
                // last used top margin
                if (headerHeight != previousMainTopMargin) {
                    //console.log('Changing <main>\'s margin-top from ' + previousMainTopMargin + ' to ' + headerHeight);
                    $('main').css('margin-top', headerHeight);
                    previousMainTopMargin = headerHeight;
                }
            } else if (previousMainTopMargin !== 0) {
                // header is *not* sticky, so change margin to zero
                $('main').css('margin-top', 0);
                previousMainTopMargin = 0;
            }
        },
        /*
        	Helper function that will be attached to the window resize event
        	to call updateMainTopMargin() after a brief delay. If this function
        	is called again before the delay is over, the previously scheduled
        	call to updateMainTopMargin() will be cancelled.
        	This prevents that function from being called many times in rapid
        	succession while the user is resizing their browser window (which
        	causes the resize event to be fired many times).
        */
        delayedUpdateMainTopMargin: function () {
            //console.log('delayedUpdateMainTopMargin');
            // Cancel any outstanding timeout
            window.clearTimeout(updateMainTopMarginTimeoutID);
            updateMainTopMarginTimeoutID = window.setTimeout(this.updateMainTopMargin, 150);
        },
        /*
        	Makes the <header> sticky.
        */
        enableStickyHeader: function () {
            if (!isHeaderSticky) {
                // make header sticky
                $('header').addClass('sticky'); // this switches <header>'s position to fixed
                isHeaderSticky = true;
                // make margin top update when window is resized because this
                // could potentially cause the height of <header> to vary.
                window.addEventListener('resize', this.delayedUpdateMainTopMargin);
                // Update <main>'s top margin as needed
                this.updateMainTopMargin();
            }
        },
        /*
        	Makes the <header> non-sticky.
        */
        disableStickyHeader: function () {
            if (isHeaderSticky) {
                // unstick header
                $('header').removeClass('sticky');
                isHeaderSticky = false;
                window.clearTimeout(updateMainTopMarginTimeoutID); // cancel outstanding margin update call
                window.removeEventListener('resize', this.delayedUpdateMainTopMargin); // stop listening to resize events
                // Update <main>'s top margin as needed
                this.updateMainTopMargin();
            }
        },
        /*
        	Schedules the header to become sticky and correctly
        	configured as soon as enough of the DOM and CSS have
        	finished loading.

        	If the page has already fully loaded, the header will
        	become sticky immediately (as if CommonHeaderView.enableStickyHeader()
        	had been called).
        */
        setupStickyHeader: function () {
            //console.log('Making header sticky!');
            var commonHeaderView = this;
            // Make header sticky asap
            if (document.readyState === 'interactive') {
                // DOM has already loaded
                commonHeaderView.enableStickyHeader();
            } else {
                // DOM not loaded yet, so schedule header
                // to go sticky once it has
                $(function () {
                    commonHeaderView.enableStickyHeader();
                });
            }
            // Update top margin once page has finished loading
            // (because <header> height may have been different
            // before all styles had finished loading)
            if (document.readyState === 'complete') {
                commonHeaderView.updateMainTopMargin();
            } else {
                $(window).load(function () {
                    commonHeaderView.updateMainTopMargin();
                });
            }
        },
    });
    return CommonHeaderView;
});