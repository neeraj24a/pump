define([
    'jquery',
    'handlebars',
    'backbone',
    'text!templates/home/homepage.tpl',
	'text!templates/home/navHeader.tpl',
	'text!templates/home/contentBody.tpl',
	'text!templates/home/footerContent.tpl',
	'owl'], function ($, Handlebars, Backbone, rawTemplate, navHeaderTemplate, contentBodyTemplate, footerTemplate) {
    var homeView = Backbone.View.extend({
        el: '#app',
        template: Handlebars.compile(rawTemplate),
        initialize: function () {
			this.render();
        },
		events: {
			"click #goto-pool": "gotoPool",
		},
        render: function () {
			var userData = {user: userInfo};
			Handlebars.registerPartial("nav", navHeaderTemplate);
			Handlebars.registerPartial("body", contentBodyTemplate);
			Handlebars.registerPartial("footer", footerTemplate);
			this.$el.html(this.template(userData));
			this.carousel();
        },
		carousel: function(){
			
			$("#owlCarousel").owlCarousel({
				navigation : true, 
				loop: true,
				autoplay: true,
				items: 1,
				loop:true,
				margin:10,
				responsiveClass:true,
			});
			
		},
		gotoPool: function(){
			window.location.href = "#pool";
		}
		
    });
    return homeView;
});