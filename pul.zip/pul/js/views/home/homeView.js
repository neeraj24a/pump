define([
    'jquery',
    'handlebars',
    'backbone',
    'text!templates/home/homepage.tpl',
	'text!templates/home/navHeader.tpl',
	'text!templates/home/contentBody.tpl',
	'text!templates/home/footerContent.tpl',
	'owl'], function ($, Handlebars, Backbone, rawTemplate, navHeaderTemplate, contentBodyTemplate, footerTemplate) {
    var homeView = Backbone.View.extend({
        el: '#app',
        template: Handlebars.compile(rawTemplate),
        initialize: function () {
			this.render();
        },
		events: {
			"click #goto-pool": "gotoPool",
		},
        render: function () {
			var userData = {user: userInfo};
			Handlebars.registerPartial("nav", navHeaderTemplate);
			Handlebars.registerPartial("body", contentBodyTemplate);
			Handlebars.registerPartial("footer", footerTemplate);
			this.$el.html(this.template(userData));
			//this.carousel();
        },
		carousel: function(){
			
			$("#owlCarousel").owlCarousel({
				navigation : false, 
				slideSpeed : 300,
				paginationSpeed : 400,
				singleItem: true,
				pagination: false,
				rewindSpeed: 500
			});
			
		},
		gotoPool: function(){
			window.location.href = "#pool";
		}
		
    });
    return homeView;
});