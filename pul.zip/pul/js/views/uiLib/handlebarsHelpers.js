define(['handlebars','moment'], function(Handlebars,moment) {
  "use strict";

  Handlebars.registerHelper('if_even', function(conditional, options) {
    if((conditional % 2) === 0) {
      return options.fn(this);
    } else {
      return options.inverse(this);
    }
  });
  Handlebars.registerHelper('formatDDMMMYYYY', function (date) {
      return moment(date).format('DD-MMM-YYYY');
  });


  Handlebars.registerHelper('with', function(context, options) {
    return options.fn(context);
  });

  //Money format
  Handlebars.registerHelper('money_format', function(numberString){
    return numberString.toMoneyFormat();
  });
    Handlebars.registerHelper('negative_number', function (numberString) {
        var numberString = String(numberString);
        if (numberString.indexOf("-") !== -1) {

            numberString = (numberString).replace("-", "(").concat(")");
        }

        return numberString;



    });
  Handlebars.registerHelper('numFormatting', function(numbers,currency,options) {
        numbers = parseFloat(numbers);
          return numbers.toMoneyFormat(2);
  });
  /*Select the dropdown by passing value */
  Handlebars.registerHelper('select', function( value, options ){
      if(options!=undefined)
      {
          var $el = $('<select />').html( options.fn(this) );
          $el.find('[value="' + value + '"]').attr({'selected':'selected'});
          return $el.html();
      }
  });

  //Formatting the %s & %d parameters form a string.
  Handlebars.registerHelper('replaceFormatting', function(numbers,string,type,options) {
      try{
		  if(type === undefined)
	      {
	        type = '%d';
	      }
	      if(typeof numbers === 'object')
	      {
	        for(var i in numbers)
	        {
	          string=string.replace(type,numbers[i])
	        }
	
	      }else
	      {
	           string=string.replace(type,numbers)
	      }
      }
      catch(e){}

      return string;
     });

     Handlebars.registerHelper('isChecked', function(val, options) {
           var fnTrue=options.fn, fnFalse=options.inverse;
           return val == 'On' ? fnTrue() : fnFalse();
     });

     //Checking conditions
     Handlebars.registerHelper('equal', function (val, check, options) {
    	 	if(typeof(check) === "object"){
    	 		if (val !== undefined)
                {
                    for(var i=0; i<check.length; i++){
                    	if(val === check[i]){
                    		return options.fn(this);
                    	}
                    }
    	 			
                }
    	 	}else{
    	 		if (val !== undefined && val === check)
                {
                    return options.fn(this);
                }
    	 	}
             

     });

     Handlebars.registerHelper('ifCheck', function(val,check,options) {
             return (val===check)?options.fn(this):options.inverse(this);
     });


      //created custom helper function for track status by Senthil S
         Handlebars.registerHelper('checkTrackStatusAcc', function (projectAmount, operator, targetAmount, options) {
           switch (operator) {
             case '>':
               return (projectAmount > targetAmount) ? options.fn(this) : options.inverse(this);
             case '<':
               return (projectAmount < targetAmount) ? options.fn(this) : options.inverse(this);
             case '==':
               return (projectAmount == targetAmount) ? options.fn(this) : options.inverse(this);
             default:
               return options.inverse(this);
           }

         });
         //created custom helper function for button display by Senthil S
         Handlebars.registerHelper( "modifyPortfolioBtnDisplay", function ( status ) {
           if (status === "A") {
               return 'show-button';
           } else {
               return '';
           }
         });
         //created custom helper function for button display by Senthil S
         Handlebars.registerHelper('startPlanningBtnDisplay', function (status)  {
             if (status === 'N') {
                 return 'show-button';
             } else  {
               return '';
             }
         });
         //created custom helper function for button display by Senthil S
         Handlebars.registerHelper('deleteBtnDisplay', function (status)  {
             if (status === 'N') {
                 return 'show-button';
             } else  {
               return '';
             }
         });
         //created custom helper function for progressbar by Senthil S
         Handlebars.registerHelper('progressbarColorDisplay', function (projectAmount, operator, targetAmount, options) {
           switch (operator) {
             case '>':
               return (projectAmount > targetAmount) ? options.fn(this) : options.inverse(this);
             case '<':
               return (projectAmount < targetAmount) ? options.fn(this) : options.inverse(this);
             case '==':
               return (projectAmount == targetAmount) ? options.fn(this) : options.inverse(this);
             default:
               return options.inverse(this);
           }

         });
         // Create custom helper function for progressbar percentage calc by Senthil S
         Handlebars.registerHelper('percentageCalculation', function (currentValue, ideal, options) {
             return Math.round(((currentValue / ideal) ) * 100);
         });
          Handlebars.registerHelper('percentageIdealCalculation', function (ideal, options) {
             return '100';
         });
          //Create custom helper for currency format
          Handlebars.registerHelper('currencyWithCommas', function (value)  {
             return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
          });

          //Create helper for replace % by Senthil S
          Handlebars.registerHelper('replacePercentage', function (string, options) {
           if (string.indexOf('%d') !== -1) {
             return new Handlebars.SafeString(string.replace('%d', ''));
           }
           return string;
         });
          Handlebars.registerHelper('formatDate', function(date) {
             return moment(date).format('MMM YYYY');
         });
          //create helper for show goal not yet planned by Senthil S
          Handlebars.registerHelper('goalNotPlanned', function (status, options)  {
             return status === 'N' ? options.fn(this) : options.inverse(this);
          });
    Handlebars.registerHelper('toLowerCase', function (str) {
        return str.toLowerCase();
    });

    /*
     * Desc: For format date "D MMM YYYY"
     * BY : Senthil S
     * FOR: Template helper
     */
    Handlebars.registerHelper('formatMonthDateYear', function (date) {
    	if(date){
    		return moment(date).format('D MMM YYYY');
    	}
    	else {
    		return "";
    	}
    });
    
    Handlebars.registerHelper('formatHoursMinutes', function (date) {
    	if(date){
    		return moment(date).format('HH:mm');
    	} else {
    		return "";
    	}
        
    });
    /*
     * Desc: For null value removed from textbox.
     * BY : Senthil S
     * FOR: Template helper
     */
     Handlebars.registerHelper('nullValueRemove', function(value){
        if (value === 'null') {
            return '';
        } else {
            return value;
        }
     });
     /*
      * To check Education Qualification Radio button Values
      * */
     Handlebars.registerHelper('ifValueEqual', function (fvalue, svalue) {
    	 if(fvalue === "M" || fvalue === "D" || fvalue === "H"){
    		 if(svalue === "M"){
    			 return true;
    		 }else {
	    		 return false;
	    	 }
    	 } else {
    		 if(fvalue === svalue){
	    		 return true;
	    	 } else {
	    		 return false;
	    	 }
    	 }
	    	
    	
     });
     
     Handlebars.registerHelper('getItemsLength', function (value) {
    	 if(value && value.length !== 0)
    		 return true;
    });
     
    
     Handlebars.registerHelper('buildDropDownList', function (text, codedIdx) {
         var val = "";
         if ($.isArray(codedIdx)) {
        	 codedIdx.forEach(function (entry, value) {
                 if (entry.codeKey == text) {
                     val += '<option value=' + entry.codeKey + ' selected>' + entry.codeDescription + '</option>';
                 } else {
                     if (entry.codeKey != "") {
                         val += '<option value=' + entry.codeKey + '>' + entry.codeDescription + '</option>';
                     }
                 }
             });
             return new Handlebars.SafeString(val);
         }
     });
     
     Handlebars.registerHelper('resultOutcome', function(value, codedIdx) {
    	 value = value.replace(']', '').replace('[', '').split(',');
    	 var tempValue = "";
         if (codedIdx && value) {
        	 for (var a = 0; a < value.length; a++){
	             for (var i = 0; i < codedIdx.length; i++) {
	                 if (codedIdx[i].codeValue === value[a].trim()) {
	                	 if(tempValue === ""){
	                		 tempValue = codedIdx[i].codeDescription;
	                	 }else{
	                		 tempValue += ", " +codedIdx[i].codeDescription;
	                	 }
	                	 break;
	                 }
	             }
        	 }
        	 if(tempValue !== ""){
        		 value = tempValue;
        	 }
             return value;
         }
     });
     
     //country check common helper
     Handlebars.registerHelper('regionSpecific', function() {
         if(arguments && arguments.length>1){
               var LV= localeInformation.models[0].get('LV'),
                    matchFound=false;
               for(var i=0; i<arguments.length-1; i++){
                     if(LVControls[arguments[i]] ===LV){
                           matchFound=true;
                           return arguments[arguments.length-1].fn(this);
                     }
               }
               if(!matchFound){
                     return arguments[arguments.length-1].inverse(this);
               }
         }
       });
     
     Handlebars.registerHelper('fundAlertFallsBy', function (amt, baseValue, percent) {
    	 var t=this;
    	 if(amt != "" && amt != undefined && Number(amt)!= 0){
    		 amt = Number(amt);
    		 baseValue = Number(baseValue);
    		 var resultAmt = baseValue - amt;
    		 return resultAmt;
    	 }else if( percent != "" && percent != undefined && Number(percent)!= 0){
    		 percent =Number(percent);
    		 baseValue = Number(baseValue);
    		 var resultAmt = baseValue - (baseValue*(percent/100));
    		 return resultAmt;
    	 }else{
    		 return;
    	 }
     });
     
     Handlebars.registerHelper('fundAlertRisesAbove', function (amt, baseValue, percent) {
    	 if(amt != "" && amt != undefined && Number(amt)!= 0){
    		 amt = Number(amt);
    		 baseValue = Number(baseValue);
    		 var resultAmt = baseValue + amt;
    		 return resultAmt;
    	 }else if( percent != "" && percent != undefined && Number(percent)!= 0){
    		 percent = Number(percent);
    		 baseValue = Number(baseValue);
    		 var resultAmt = baseValue + (baseValue*(percent/100));
    		 return resultAmt;
    	 }else{
    		 return;
    	 }
     });
     
     Handlebars.registerHelper('ifNotEqual', function(val,options) {
         if(val || val === 0){        
        	 return options.fn(this);
         }
     });
     Handlebars.registerHelper('fundAlertCheckAlertTypeForProductCode', function(resp, fullResp, options) {
         if(resp.attributes.levelIndicator === "FH" || resp.attributes.levelIndicator === "FW"){        
        	 return resp.attributes.productCode;
         }else if(resp.attributes.levelIndicator === "R"){
        	 var relNum = resp.attributes.relationshipNumber;
        	 for(var i=0; i<fullResp.attributes.relationshipNumberList.length; i++){
        		 if(relNum === fullResp.attributes.relationshipNumberList[i].relationshipNumber)
        			 return fullResp.attributes.relationshipNumberList[i].relationshipNumber;
        	 }        	
         }else if(resp.attributes.levelIndicator === "A"){
        	 var accNum = resp.attributes.accountNumber;
        	 for(var i=0; i<fullResp.attributes.accountNumberList.length; i++){
        		 if(accNum === fullResp.attributes.accountNumberList[i].accountNumber)
        			 return fullResp.attributes.accountNumberList[i].accountNumber;
        	 }        	
         }
     });
     Handlebars.registerHelper('fundAlertCheckAlertTypeForProductName', function(resp, fullResp, options) {
         if(resp.attributes.levelIndicator === "FH" || resp.attributes.levelIndicator === "FW"){        
        	 return resp.attributes.productName;
         }else if(resp.attributes.levelIndicator === "R"){
        	 var relNum = resp.attributes.relationshipNumber;
        	 for(var i=0; i<fullResp.attributes.relationshipNumberList.length; i++){
        		 if(relNum === fullResp.attributes.relationshipNumberList[i].relationshipNumber)
        			 return fullResp.attributes.relationshipNumberList[i].relationshipName;
        	 }        	
         }else if(resp.attributes.levelIndicator === "A"){
        	 var accNum = resp.attributes.accountNumber;
        	 for(var i=0; i<fullResp.attributes.accountNumberList.length; i++){
        		 if(accNum === fullResp.attributes.accountNumberList[i].accountNumber)
        			 return fullResp.attributes.accountNumberList[i].systemIDDescription;
        	 }        	
         }
     });
     Handlebars.registerHelper('getCodedValues', function(data, type, options) {
    	 var cond = _.findWhere(languageBundle.getCodedValues('RA_PROD_TYPE'),{codeValue : type});
    	 return cond?cond.codeDescription:"";
     });
     
     Handlebars.registerHelper('checkFlags', function(data, value, options) {
    	 
    	 if(data === value && value === "Y")
    		 return options.fn(this);
    	 if(value==="N" && (data === value))
    		 return options.fn(this);
     });
     

     Handlebars.registerHelper('citiOr', function(data1, data2, options) {    	 
    	return data1 || data2;
     });
	 Handlebars.registerHelper('allocatedAmtPcyHelper',function(info) {	     
	     var goalID= localeInformation.models[0].get('goalID');
	     var assignToGoalInfo = info;
	     var value;
	     if(typeof assignToGoalInfo == "undefined" || assignToGoalInfo == ""){
	    	 value = 0;	 
	     }else{	    	
	    	 for(var x in assignToGoalInfo){
	 	    	if((assignToGoalInfo[x].assignToGoalID==goalID )&&(assignToGoalInfo[x].allocatedPer !== "")){
	 	    		
	 	    			value= assignToGoalInfo[x].allocatedAmtPcy;	 	    	}
	 	     }	
	     }
	     value = Handlebars.helpers.formatAmount(value);
		return value;
	});
	Handlebars.registerHelper('allocatedAmtRcyHelper',function(info) {	     
	     var goalID= localeInformation.models[0].get('goalID');
	     var assignToGoalInfo = info;
	     var value;
	     if(typeof assignToGoalInfo == "undefined" || assignToGoalInfo == ""){
	    	 value = 0;	 
	     }else{	    	
	    	 for(var x in assignToGoalInfo){
	 	    	if((assignToGoalInfo[x].assignToGoalID==goalID )&&(assignToGoalInfo[x].allocatedPer !== "")){    		
	 	    		value= assignToGoalInfo[x].allocatedAmtRcy;	 	    		    		
	 	    	}
	 	     }	
	     }
	    value = Handlebars.helpers.formatAmount(value);
		return value;	
	});	
	Handlebars.registerHelper('changeToPercentage',function(val) {    
		if(!val || val==""){
	    	 val=0;	 
	     } 
		return val+"%";
	});
	//Returns Entire Shares Notes String with formating based on Holding Flag
	Handlebars.registerHelper('sharesUnitsHelper', function(productType, isHoldingFlag, assignedUnits, allocatedUnits) {
		if(productType != undefined){
			var quantity;
			if(isHoldingFlag == "Y"){
				quantity = assignedUnits;
			}else{
				quantity = allocatedUnits;
			}
			if(typeof quantity == "undefined" ||quantity ==""){
				quantity=0;					
			}
			/*if(productType.toUpperCase() === "MF"){
				quantity = parseInt(quantity);
				return quantity.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
			} else if (productType.toUpperCase() === "FIS" || productType.toUpperCase() === "SN" || productType.toUpperCase() === "EQ"){
				return Handlebars.helpers.formatAmount(quantity, 'UNITS');				
			}*/
			return Handlebars.helpers.formatAmount(quantity, 'UNITS');
		}
		return " ";
	}); 
	Handlebars.registerHelper('transactionTypeHelper',function(isHolding,productType) {    
		
		if(isHolding == "N"){
			if (productType == "RSP"){
				return "RSP";
			}else{
				return "BUY";
			}	    	
	    }		
	});
	Handlebars.registerHelper('cditooltipHelper',function(val) {  
		if(typeof val == 'undefined' || val == ""){
			return 0;
	    }else{
	    	return val;
	    }		
	});
	Handlebars.registerHelper('cdiLevelText',function(level,type) {  
		if(typeof level == 'undefined' || level == ""){			
				return "Low";						
	    }else{
	    	return level;
	    }		
	});
	
	Handlebars.registerHelper('getProductTypeDescription',function(options) {  
		if(options.hash.productType && languageBundle.getCodedValues('RA_PROD_TYPE')) {
			var productType = options.hash.productType;
			return _.findWhere(languageBundle.getCodedValues('RA_PROD_TYPE'), {codeKey: productType}).codeDescription;
			
		}	
	});
	
     
});
