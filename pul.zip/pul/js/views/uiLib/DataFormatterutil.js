var App = App || {};
define(['moment'], function (moment) {
App.DataFormatter = {
    formatNumber: function (numberString) {
        numberString = parseFloat(numberString);
        return numberString.toMoneyFormat(2); 
    },
   
    DateFormat: function (date) {
     return moment(date).format('DD MMM YYYY');
   },
   DateFormat1: function (date) {
	     return moment(date).format('MM/DD/YYYY');
	},
	Negative_number: function (numberString) {

        var numberString = parseFloat(numberString);

        numberString = numberString.toMoneyFormat(2);

        numberString = String(numberString);

        if (numberString.indexOf("-") !== -1) {

            numberString = (numberString).replace("-", "(").concat(")");

        }

        return numberString;

    }

};
});