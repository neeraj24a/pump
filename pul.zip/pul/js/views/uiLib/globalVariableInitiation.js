/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * 
 */
var App = App || {};
// this should at global level with proper naming convention of DataTypes
(function() {
	if (typeof App.Enums == 'undefined') {

	    App.Enums = {
	        Table: {
	            ColTypes: {
	            	STRING                  : 0,
	                DATE                    : 1,
	                UNITS                   : 2,
	                AMOUNT                  : 3,
	                PERCENT                 : 4,
	                ACCOUNTNUMBER           : 5,
	                PRODUCTNAME             : 6,
	                PRODUCTCODE             : 7,
	                ISIN                    : 8,
	                TENGER                  : 9,
	                ICONS                   : 10,
	                PRR                     : 11,
	                CURRENCYSTRING          : 12,
	                STRING_ACCORDION        : 13,
	                AMOUNT_BOLD             : 14,
	                AMOUNT_BOLD_BROWN       : 15,
	                AMOUNT_BROWN            : 16,
	                PRODUCTTYPE             : 17,
	                INDICATIVEPRICE         : 18,
	                STATUS                  : 19,
	                RADIOBTN                : 20,
	                STRING_BOLD             : 21,
	                PERCENT_EXTENDED		: 22,
	                FXRATE					: 23,
					NUMBER					: 24,
					PRICE					: 25,
					PERCENTROUNDOFF			: 26,
					PERCENT_EXTEND			: 27
	            }
	        }
	    }
	    Object.freeze(App.Enums.Table.ColTypes); // makes sure enum is not changed by consumers
	}
	if (typeof App.tableRender === "undefined") {
	    App.tableRender = [];
	}
}());

